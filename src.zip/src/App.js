import { BrowserRouter as Router, Route, Switch} from 'react-router-dom'

// context
import {SolutionProvider} from '../src/utils/context/context';

// component
import Register from '../src/components/authentification/register';
import Login from '../src/components/authentification/login';
import Dashboard from '../src/components/dashboard/home';
import Solution from '../src/components/solution/solution';
import Results from '../src/components/result/index';

function App() {
  return (
    <Router>
      <SolutionProvider>
      <Switch>
      <Route path="/register">
            <Register />
          </Route>
          <Route path="/login">
            <Login />
          </Route>
          <Route exact path="/">
            <Dashboard />
          </Route>
          <Route path="/solution/:questionNumber">
              <Solution />
          </Route>
          <Route path="/results">
            <Results />
          </Route>
        </Switch>
      </SolutionProvider>
    </Router>
  );
}

export default App;
