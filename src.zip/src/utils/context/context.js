import React, { useState, createContext } from 'react'

export const SolutionContext = createContext()

export const SolutionProvider = ({ children }) => {
  const [answers, setAnswers] = useState({})
  const saveAnswers = (newAnswers) => {
    setAnswers({ ...answers, ...newAnswers })
  }

  return (
    <SolutionContext.Provider value={{ answers, saveAnswers }}>
      {children}
    </SolutionContext.Provider>
  )
}
