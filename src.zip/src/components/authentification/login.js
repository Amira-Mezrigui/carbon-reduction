import React, {useState} from 'react';
import './auth.css';

import { Col, Row, Form, Button } from 'react-bootstrap';


export default function Login () {
    const [logged,setLogged]= useState(false)

    const loggedIn= () => {
        setLogged(true);
        localStorage.setItem('login', true);
        window.location.assign('/');
        // localStorage.clear();
    }
        return (
                    <Row className="mx-0 px-0 justify-content-center">
                        <Col xl="9" lg="9" md="8" xs="10">
                            <h1 className="auth-title"> Log in </h1>
                            <p className="auth-text"> Welcome dear member </p>
                        </Col>
                        <Col xl="10" lg="10" md="8" xs="10">
                            <Form.Group>
                                <Form.Control size="sm" className="auth-input px-4 my-4" type="email" placeholder="E-mail" />
                            </Form.Group> 
                        </Col>
                        <Col xl="10" lg="10" md="8" xs="10">
                            <Form.Group>
                                <Form.Control size="sm" className="auth-input px-4 my-4" type="password" placeholder="Mot de passe" />
                            </Form.Group> 
                        </Col>

                        <Col xl="10" lg="10" md="8" xs="10">
                            <Button className="auth-form-btn" onClick={() => loggedIn()}> Se connecter </Button>
                        </Col>
                    </Row>

        )
    }