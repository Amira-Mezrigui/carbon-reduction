import React from 'react';
import './auth.css';

import { Col, Row, Form, Button } from 'react-bootstrap';
import { Link } from 'react-router-dom';


export default function Register() {

        return (
                    <Row className="mx-0 px-0 my-5 justify-content-center">
                        <Col xl="8" lg="10" md="10" xs="10" className="mx-5" >
                            <h1 className="auth-title my-0"> Register </h1>
                            <p className="auth-text"> We are glad to be a member of our carbon reduction emission app  </p>
                        </Col>
                        <Col xl="10" lg="10" md="8" xs="10">
                            <Form.Group>
                                <Form.Control size="sm" className="auth-input my-4" type="text" placeholder="Nom" />
                            </Form.Group> 
                        </Col>
                        <Col xl="10" lg="10" md="8" xs="10">
                            <Form.Group>
                                <Form.Control size="sm" className="auth-input my-4" type="text" placeholder="Prénom" />
                            </Form.Group> 
                        </Col>
                        <Col xl="10" lg="10" md="8" xs="10">
                            <Form.Group>
                                <Form.Control size="sm" className="auth-input my-4" type="email" placeholder="E-mail" />
                            </Form.Group> 
                        </Col>
                        <Col xl="10" lg="10" md="8" xs="10">
                            <Form.Group>
                                <Form.Control size="sm" className="auth-input my-4" type="text" placeholder="Numéro de téléphone" />
                            </Form.Group> 
                        </Col>
                        <Col xl="10" lg="10" md="8" xs="10">
                            <Form.Group>
                                <Form.Control size="sm" className="auth-input my-4" type="text" placeholder="Pays" />
                            </Form.Group> 
                        </Col>
                        <Col xl="10" lg="10" md="8" xs="10">
                            <Form.Group>
                                <Form.Control size="sm" className="auth-input my-4" type="text" placeholder="Gouvernorat" />
                            </Form.Group> 
                        </Col>
                        <Col xl="10" lg="10" md="8" xs="10">
                            <Form.Group>
                                <Form.Control size="sm" className="auth-input my-4" type="password" placeholder="Mot de passe" />
                            </Form.Group> 
                        </Col>
                        <Col xl="10" lg="10" md="8" xs="10">
                            <Form.Group>
                                <Form.Control size="sm" className="auth-input my-4" type="text" placeholder="Retaper mot de passe" />
                            </Form.Group> 
                        </Col>

                        <Col xl="10" lg="10" md="8" xs="10">
                            <Button className="auth-form-btn my-0"> S'ABONNER </Button>
                        </Col>
                        <Col xl="10" lg="10" md="8" xs="10">
                            <p className="register-text mt-0 mb-2"> Vous avez déjà un compte? 
                               <Link to='/login'> <span className="register-span"> Se Connecter </span> </Link>
                            </p> 
                        </Col>
                    </Row>

        )
    }