import React, {useState, useEffect} from 'react';
import './home.css'
import { Row, Container} from 'react-bootstrap';
//data
import {user} from '../../api/user';
import {consuption} from '../../api/consuption'
import { Link } from 'react-router-dom';


export default function Login () {

    const [totalConsuption,setTotal]= useState(0)

    useEffect(() => {
        calculate(consuption);
      }, []);

    const calculate =(data) => {
        let totalKwh = 0;
        for (let i = 0; i < data.length; i++) {
            totalKwh += data[i].kwh;
        }
        setTotal(totalKwh);
    }
        return (
        <Container fluid className="mx-0 px-0">

        <Row className="mx-0 my-5 mt-5 mb-2 px-0">
            <p className="welcome-msg"> Welcome Dear {user.name}  </p>
        </Row>
        <Row className="mx-0 px-0 justify-content-center">
            <div className="px-0 mx-5 px-5">
                <h2 className=""> Your average consumption is : {totalConsuption} </h2>
                <p> This consuption is from the date of {consuption[0].start_date} to the date of {consuption[consuption.length-1].end_date}  </p>
                <p> "Don't panic, you can reduce this carbon emission consumption." </p>
            </div>
        </Row>
        <Row className="mx-0 px-0 justify-content-center">
            <p className="px-0 mx-5 px-5">
                Identify your needs, we'll take care of the rest, with the best solutions.
            </p>
            <Link to="/solution/1" className="px-0 mx-5 px-5">
                Solution 
            </Link>
        </Row>
        </Container>
    )
    }
