import { useContext } from 'react'
import { useParams, Link } from 'react-router-dom'
import styled from 'styled-components'

//context
import { SolutionContext } from '../../utils/context/context'
//api
import {plan} from '../../api/reduction-plan'

const SolutionContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
`

const QuestionTitle = styled.h2`
  text-decoration: underline;
  text-decoration-color: '#000000';
  color: '#000000' : '#000000';
`

const QuestionContent = styled.span`
  margin: 30px;
  color:'#000000';
`

const LinkWrapper = styled.div`
  padding-top: 30px;
  & a {
    color: '#000000';
  }
  & a:first-of-type {
    margin-right: 20px;
  }
`

const ReplyBox = styled.button`
  border: none;
  height: 80px;
  width: 200px;
  display: flex;
  align-items: center;
  justify-content: center;

  color: '#000000' : '#ffffff';
  border-radius: 30px;
  cursor: pointer;
  box-shadow: ${(props) =>
    props.isSelected ? `0px 0px 0px 2px #000000 inset` : 'none'};
  &:first-child {
    margin-right: 15px;
  }
  &:last-of-type {
    margin-left: 15px;
  }
`

const ReplyWrapper = styled.div`
  display: flex;
  flex-direction: row;
`

export default function Solution() {
  const { questionNumber } = useParams()
  const questionNumberInt = parseInt(questionNumber)
  const prevQuestionNumber = questionNumberInt === 1 ? 1 : questionNumberInt - 1
  const nextQuestionNumber = questionNumberInt + 1

  const { saveAnswers, answers } = useContext(SolutionContext)

  function saveReply(answer) {
    saveAnswers({ [questionNumber]: answer })
  }
  const solutionData = plan[questionNumber-1];



  return (
    <SolutionContainer>
      <QuestionTitle >Question {questionNumber} </QuestionTitle>
        <QuestionContent >
          you want to  :  {solutionData.plan} ?
        
        </QuestionContent>
      <ReplyWrapper>
        <ReplyBox
          onClick={() => saveReply(2024)}
          isSelected={answers[questionNumber] === 2024}
  
        >
          2024
        </ReplyBox>

        <ReplyBox
          onClick={() => saveReply(2025)}
          isSelected={answers[questionNumber] === 2025}
        >
          2025
        </ReplyBox>

        <ReplyBox
          onClick={() => saveReply(2026)}
          isSelected={answers[questionNumber] === 2026}
        >
          2026
        </ReplyBox>

        <ReplyBox
          onClick={() => saveReply(2027)}
          isSelected={answers[questionNumber] === 2027}
        >
          2027
        </ReplyBox>

        <ReplyBox
          onClick={() => saveReply(2028)}
          isSelected={answers[questionNumber] === 2028}
        >
          2028
        </ReplyBox>
      </ReplyWrapper>
      <LinkWrapper>
        <Link to={`/solution/${prevQuestionNumber}`}>Précédent</Link>
        {solutionData && questionNumberInt<plan.length ? (
          <Link to={`/solution/${nextQuestionNumber}`}>Suivant</Link>
        ) : (
          <Link to="/results">Résultats</Link>
        )}
      </LinkWrapper>
    </SolutionContainer>
  )
}