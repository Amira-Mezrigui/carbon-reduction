import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { SolutionContext } from '../../utils/context/context';
import Solution from './solution';
import { BrowserRouter as Router } from 'react-router-dom';

describe('Solution component', () => {
  test('should save selected reply when clicked', () => {
    const saveAnswersMock = jest.fn();
    const answersMock = {};
    const questionNumberMock = '1';

    render(
      <Router>
        <SolutionContext.Provider value={{ saveAnswers: saveAnswersMock, answers: answersMock }}>
          <Solution />
        </SolutionContext.Provider>
      </Router>
    );

    const replyButton = screen.getByText('2024');
    fireEvent.click(replyButton);

    expect(saveAnswersMock).toHaveBeenCalledWith({ '1': 2024 });
  });

  test('should navigate to the previous question when "Précédent" link is clicked', () => {
    const saveAnswersMock = jest.fn();
    const answersMock = {};
    const questionNumberMock = '2';

    render(
      <Router>
        <SolutionContext.Provider value={{ saveAnswers: saveAnswersMock, answers: answersMock }}>
          <Solution />
        </SolutionContext.Provider>
      </Router>
    );

    const previousLink = screen.getByText('Précédent');
    fireEvent.click(previousLink);

  });

});