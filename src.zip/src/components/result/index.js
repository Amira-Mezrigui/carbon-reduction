import { useContext, useEffect, useState } from 'react'
import { SolutionContext } from '../../utils/context/context'
import styled from 'styled-components'


//api 
import {plan} from '../../api/reduction-plan'
import {emission_factor} from '../../api/emission-factor'

const ResultsContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  margin: 60px 90px;
  padding: 30px;

`

const ResultsTitle = styled.h2`
  color: '#4796c5';
  font-weight: bold;
  font-size: 28px;
  max-width: 60%;
  text-align: center;
  & > span {
    padding-left: 10px;
  }
`




function Results() {
const [total,setTotal]= useState(0)
const [first,setFirst]= useState(0)
const [second,setSecond]= useState(0)
const [third,setThird]= useState(0)
const [four,setFourth]= useState(0)
const [five,setFive]= useState(0)




  const { answers } = useContext(SolutionContext)

  useEffect(() => {
    calculateReduction();
  }, []);


  const calculateReduction = () => {
    let data = Object.values(answers)
    let total = 0
    let f = 0;
    let s = 0;
    let t = 0;
    let f4 = 0;
    let f5 = 0;

    plan.forEach(value => {
        let a = parseInt(data[value.id])
        let matchingYear = emission_factor.find((item) => item.year == a);

        if (matchingYear) {
          total=parseInt(value.reduction)*matchingYear.ef + total
          if(matchingYear.year==2024){
            f = f+parseInt(value.reduction)*matchingYear.ef
          }
          if(matchingYear.year==2025){
            s = s+parseInt(value.reduction)*matchingYear.ef
          }

          if(matchingYear.year==2026){
            t = t+parseInt(value.reduction)*matchingYear.ef
          }
          if(matchingYear.year==2027){
            f4 = f4+parseInt(value.reduction)*matchingYear.ef
          }
          if(matchingYear.year==2028){
            f5 = f5+parseInt(value.reduction)*matchingYear.ef
          }
        } else {
            total=0*matchingYear.ef + total
        }
      });
      setTotal(total);
      setFirst(f)
      setSecond(s)
      setThird(t)
      setFourth(f4)
      setFive(f5)



  }


//   const resultsData = data?.resultsData

  return  (
    <ResultsContainer >
      <ResultsTitle >
        Congratulation your average carbon reduction is :{total} 
      </ResultsTitle>
      <p>  Reduction of 2024 : {first} </p>
      <p>  Reduction of 2025 : {second} </p>
      <p>  Reduction of 2026 : {third} </p>
      <p>  Reduction of 2027 : {four} </p>
      <p>  Reduction of 2028 : {five} </p>

    </ResultsContainer>
  )
}

export default Results
