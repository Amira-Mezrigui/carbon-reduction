export const emission_factor =[
    {
        year: 2020,
        ef:0.05
    },
    {
        year: 2021,
        ef:0.05
    },
    {
        year: 2022,
        ef:0.04
    },
    {
        year: 2023,
        ef:0.04
    },
    {
        year: 2024,
        ef:0.04
    },
    {
        year: 2025,
        ef:0.03
    },
    {
        year: 2026,
        ef:0.03
    },
    {
        year: 2027,
        ef:0.03
    },
    {
        year: 2028,
        ef:0.03
    },
    {
        year: 2029,
        ef:0.02
    },
    {
        year: 2030,
        ef:0.02
    },
]