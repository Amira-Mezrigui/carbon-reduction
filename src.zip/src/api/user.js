export const user = {
    id:1,
    name: "amira",
    adress : "la garenne colombes",
    home: "Apartment"
}