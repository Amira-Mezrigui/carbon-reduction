export const consuption = [
    {
    id_user : 1,
    start_date : "05/01/2023",
    end_date : "05/03/2023",
    kwh : 750
    },
    {
    id_user : 1,
    start_date : "05/03/2023",
    end_date : "05/05/2023",
    kwh : 650
    },
    {
    id_user : 1,
    start_date : "05/05/2023",
    end_date : "05/07/2023",
    kwh : 500
    },
    {
    id_user : 1,
    start_date : "05/07/2023",
    end_date : "05/09/2023",
    kwh : 400
    },
    {
    id_user : 1,
    start_date : "05/09/2023",
    end_date : "05/11/2023",
    kwh : 550
    },
    {id_user : 1,
    start_date : "05/11/2023",
    end_date : "05/12/2023",
    kwh : 400
    },
];