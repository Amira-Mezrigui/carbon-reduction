export const plan = [
    {
        id:0,
        plan:"Buy Thermostat",
        reduction: 280,
    },
    {
        id:1,
        plan:"LED lights",
        reduction: 100
    },
    {
        id:2,
        plan:"Replace old gadgets with 5-star gadget",
        reduction: 300
    },
    {
        id:3,
        plan:"Reduce Thermostat by 2 deg",
        reduction: 260
    },
    {
        id:4,
        plan:"Solar",
        reduction: 500
    },
    {
        id:5,
        plan:"Turn off devices on standby",
        reduction: 150
    },

]